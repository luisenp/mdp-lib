#../planner -x 1000 -r 100 -v 100 -h "atom-min-1-forward" 0:2412 ../../examples/bw-det-10-exp-1.pddl bw-det-10 2> /dev/null > hmax1-bw-10
#grep "state-value" hmax1-bw-10 | awk '{ ++i; printf "r%d %s\n", i, $2; }' | sort > tmp-max1-bw-10

#../planner -x 1000 -r 100 -v 100 -h "atom-min-1-backward" 0:2412 ../../examples/bw-det-10-exp-1.pddl bw-det-10 2> /dev/null > db1-bw-10
#grep "state-value" db1-bw-10 | awk '{ ++i; printf "r%d %s\n", i, $2; }' | sort > tmp-db1-bw-10

#../planner -x 1000 -r 100 -v 100 -h "atom-min-1-backward" 0:2412 ../../examples/bw-det-10-exp-2.pddl bw-det-10 2> /dev/null > db2-bw-10
#grep "state-value" db2-bw-10 | awk '{ ++i; printf "r%d %s\n", i, $2; }' | sort > tmp-db2-bw-10

cat hsps-bw-10 | grep bound | awk '{ ++i; printf "r%d %d\n",i,$3; }' | sort > tmp-max2-bw-10

join tmp-sol-bw-10 tmp-db2-bw-10 | join - tmp-db1-bw-10 | join - tmp-max2-bw-10 | join - tmp-max1-bw-10 > tmp-join-bw-10
cat tmp-join-bw-10 | awk 'BEGIN {printf "(define diff1 (list ";} { printf "%d ",$2-$3; } END { printf "))\n\n";}' > diff-bw-10.scm
cat tmp-join-bw-10 | awk 'BEGIN {printf "(define diff2 (list ";} { printf "%d ",$2-$4; } END { printf "))\n\n";}' >> diff-bw-10.scm
cat tmp-join-bw-10 | awk 'BEGIN {printf "(define diff3 (list ";} { printf "%d ",$2-$5; } END { printf "))\n\n";}' >> diff-bw-10.scm
cat tmp-join-bw-10 | awk 'BEGIN {printf "(define diff4 (list ";} { printf "%d ",$2-$6; } END { printf "))\n\n";}' >> diff-bw-10.scm
cat tmp-join-bw-10 | awk 'BEGIN {printf "(define diff5 (list ";} { printf "%d ",$3-$4; } END { printf "))\n\n";}' >> diff-bw-10.scm
cat tmp-join-bw-10 | awk 'BEGIN {printf "(define diff6 (list ";} { printf "%d ",$3-$5; } END { printf "))\n\n";}' >> diff-bw-10.scm
cat tmp-join-bw-10 | awk 'BEGIN {printf "(define diff7 (list ";} { printf "%d ",$3-$6; } END { printf "))\n\n";}' >> diff-bw-10.scm
cat tmp-join-bw-10 | awk 'BEGIN {printf "(define diff8 (list ";} { printf "%d ",$4-$5; } END { printf "))\n\n";}' >> diff-bw-10.scm
cat tmp-join-bw-10 | awk 'BEGIN {printf "(define diff9 (list ";} { printf "%d ",$4-$6; } END { printf "))\n\n";}' >> diff-bw-10.scm
cat tmp-join-bw-10 | awk 'BEGIN {printf "(define diff10 (list ";} { printf "%d ",$5-$6; } END { printf "))\n\n";}' >> diff-bw-10.scm

echo "(define ldiff (list diff1 diff2 diff3 diff4 diff5 diff6 diff7 diff8 diff9 diff10)) (newline)" >> diff-bw-10.scm
echo "(display (map (lambda (d) (length d)) ldiff)) (newline)" >> diff-bw-10.scm
echo "(display (map (lambda (d) (util-statistics d)) ldiff)) (newline)" >> diff-bw-10.scm
