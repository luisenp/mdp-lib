#./planner -x 1000 -r 100 -v 100 -h "atom-min-1-forward" 0:2412 ../examples/tile8-manhattan.pddl i1 2> /dev/null > hmax1-tile-8
#grep "state-value" hmax1-tile-8 | awk '{ ++i; printf "r%d %s\n", i, $2; }' | sort > tmp-max1-tile-8

#./planner -x 1000 -r 100 -v 100 -h "atom-min-1-backward" 0:2412 ../examples/tile8-manhattan.pddl i1 2> /dev/null > db1-tile-8
#grep "state-value" db1-tile-8 | awk '{ ++i; printf "r%d %s\n", i, $2; }' | sort > tmp-db1-tile-8

#./planner -x 1000 -r 100 -v 100 -h "atom-min-1-backward" 0:2412 ../examples/tile8-sum-pair.pddl i1 2> /dev/null > db2-tile-8
#grep "state-value" db2-tile-8 | awk '{ ++i; printf "r%d %s\n", i, $2; }' | sort > tmp-db2-tile-8

#grep init manhattan-8 | nawk 'BEGIN { FS="[\ \(\)]+"; } { for(i=2;i<NF;++i) print $i; }' | nawk 'BEGIN { FS="_"; i=0; } /:init/ { if(i>0) { for(i=0;i<9;++i) printf "%d ",line[i]; printf "\n"; } for(i=0;i<9;++i) line[i]=0; } $0!~/:init/ { ++i; if( $2 != "blank" ) { tile=substr($2,2); row=substr($3,2); col=substr($4,2); pos=3*(row-1)+(col-1); line[pos]=tile; } } END { for(i=0;i<9;++i) printf "%d ",line[i]; printf "\n"; }' > tile-instances-8

#cat tile-instances-8 | nawk '{ system( "../../n-puzzle/puzzle 3 \"" $0 "\"" ); }' | grep last | awk '{ ++i; printf "r%d %s\n",i,$4; }' | sort > tmp-sol-tile-8
cat hsps-tile-8 | grep "^Initial bound" | awk '{ ++i; printf "r%d %d\n",i,$3; }' | sort > tmp-max2-tile-8

join tmp-sol-tile-8 tmp-db2-tile-8 | join - tmp-db1-tile-8 | join - tmp-max2-tile-8 | join - tmp-max1-tile-8 > tmp-join-tile-8
cat tmp-join-tile-8 | awk 'BEGIN {printf "(define diff1 (list ";} { printf "%d ",$2-$3; } END { printf "))\n\n";}' > diff-tile-8.scm
cat tmp-join-tile-8 | awk 'BEGIN {printf "(define diff2 (list ";} { printf "%d ",$2-$4; } END { printf "))\n\n";}' >> diff-tile-8.scm
cat tmp-join-tile-8 | awk 'BEGIN {printf "(define diff3 (list ";} { printf "%d ",$2-$5; } END { printf "))\n\n";}' >> diff-tile-8.scm
cat tmp-join-tile-8 | awk 'BEGIN {printf "(define diff4 (list ";} { printf "%d ",$2-$6; } END { printf "))\n\n";}' >> diff-tile-8.scm
cat tmp-join-tile-8 | awk 'BEGIN {printf "(define diff5 (list ";} { printf "%d ",$3-$4; } END { printf "))\n\n";}' >> diff-tile-8.scm
cat tmp-join-tile-8 | awk 'BEGIN {printf "(define diff6 (list ";} { printf "%d ",$3-$5; } END { printf "))\n\n";}' >> diff-tile-8.scm
cat tmp-join-tile-8 | awk 'BEGIN {printf "(define diff7 (list ";} { printf "%d ",$3-$6; } END { printf "))\n\n";}' >> diff-tile-8.scm
cat tmp-join-tile-8 | awk 'BEGIN {printf "(define diff8 (list ";} { printf "%d ",$4-$5; } END { printf "))\n\n";}' >> diff-tile-8.scm
cat tmp-join-tile-8 | awk 'BEGIN {printf "(define diff9 (list ";} { printf "%d ",$4-$6; } END { printf "))\n\n";}' >> diff-tile-8.scm
cat tmp-join-tile-8 | awk 'BEGIN {printf "(define diff10 (list ";} { printf "%d ",$5-$6; } END { printf "))\n\n";}' >> diff-tile-8.scm

echo "(define ldiff (list diff1 diff2 diff3 diff4 diff5 diff6 diff7 diff8 diff9 diff10)) (newline)" >> diff-tile-8.scm
echo "(display (map (lambda (d) (length d)) ldiff)) (newline)" >> diff-tile-8.scm
echo "(display (map (lambda (d) (util-statistics d)) ldiff)) (newline)" >> diff-tile-8.scm

