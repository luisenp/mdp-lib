#./planner -x 1000 -r 100 -v 100 -h "atom-min-1-forward" 0:2411 ../examples/tile15-manhattan.pddl i1 2> /dev/null > hmax1-15
#grep "state-value" hmax1-15 | awk '{ ++i; printf "r%d %s\n", i, $2; }' | sort > tmp-max1-15

#./planner -x 1000 -r 100 -v 100 -h "atom-min-1-backward" 0:2411 ../examples/tile15-manhattan.pddl i1 2> /dev/null > manhattan-15
#grep "state-value" manhattan-15 | awk '{ ++i; printf "r%d %s\n", i, $2; }' | sort > tmp-manh-15

#./planner -x 1000 -r 100 -v 100 -h "atom-min-1-backward" 0:2411 ../examples/tile15-sum-pair.pddl i1 2> /dev/null > sum-pair-15
#grep "state-value" sum-pair-15 | awk '{ ++i; printf "r%d %s\n", i, $2; }' | sort > tmp-pair-15

#grep init manhattan-15 | nawk 'BEGIN { FS="[\ \(\)]+"; } { for(i=2;i<NF;++i) print $i; }' | nawk 'BEGIN { FS="_"; i=0; } /:init/ { if(i>0) { for(i=0;i<16;++i) printf "%d ",line[i]; printf "\n"; } for(i=0;i<16;++i) line[i]=0; } $0!~/:init/ { ++i; if( $2 != "blank" ) { tile=substr($2,2); row=substr($3,2); col=substr($4,2); pos=4*(row-1)+(col-1); line[pos]=tile; } } END { for(i=0;i<16;++i) printf "%d ",line[i]; printf "\n"; }' > puzzle-instances-15

#cat puzzle-instances-15 | nawk '{ system( "../../n-puzzle/puzzle2 \"" $0 "\"" ); }' | grep threshold | awk '{ ++i; printf "r%d %s\n",i,$NF; }' | sort > tmp-sol-15
cat hsps-tile-15 | grep "^Initial bound" | awk '{ ++i; printf "r%d %d\n",i,$3; }' | sort > tmp-max2-tile-15

join tmp-sol-tile-15 tmp-db2-tile-15 | join - tmp-db1-tile-15 | join - tmp-max2-tile-15 | join - tmp-max1-tile-15 > tmp-join-tile-15
cat tmp-join-tile-15 | awk 'BEGIN {printf "(define diff1 (list ";} { printf "%d ",$2-$3; } END { printf "))\n\n";}' >  diff-tile-15.scm
cat tmp-join-tile-15 | awk 'BEGIN {printf "(define diff2 (list ";} { printf "%d ",$2-$4; } END { printf "))\n\n";}' >> diff-tile-15.scm
cat tmp-join-tile-15 | awk 'BEGIN {printf "(define diff3 (list ";} { printf "%d ",$2-$5; } END { printf "))\n\n";}' >> diff-tile-15.scm
cat tmp-join-tile-15 | awk 'BEGIN {printf "(define diff4 (list ";} { printf "%d ",$2-$6; } END { printf "))\n\n";}' >> diff-tile-15.scm
cat tmp-join-tile-15 | awk 'BEGIN {printf "(define diff5 (list ";} { printf "%d ",$3-$4; } END { printf "))\n\n";}' >> diff-tile-15.scm
cat tmp-join-tile-15 | awk 'BEGIN {printf "(define diff6 (list ";} { printf "%d ",$3-$5; } END { printf "))\n\n";}' >> diff-tile-15.scm
cat tmp-join-tile-15 | awk 'BEGIN {printf "(define diff7 (list ";} { printf "%d ",$3-$6; } END { printf "))\n\n";}' >> diff-tile-15.scm
cat tmp-join-tile-15 | awk 'BEGIN {printf "(define diff8 (list ";} { printf "%d ",$4-$5; } END { printf "))\n\n";}' >> diff-tile-15.scm
cat tmp-join-tile-15 | awk 'BEGIN {printf "(define diff9 (list ";} { printf "%d ",$4-$6; } END { printf "))\n\n";}' >> diff-tile-15.scm
cat tmp-join-tile-15 | awk 'BEGIN {printf "(define diff10 (list ";} { printf "%d ",$5-$6; } END { printf "))\n\n";}' >>diff-tile-15.scm

echo "(define ldiff (list diff1 diff2 diff3 diff4 diff5 diff6 diff7 diff8 diff9 diff10)) (newline)" >> diff-tile-15.scm
echo "(display (map (lambda (d) (length d)) ldiff)) (newline)" >> diff-tile-15.scm
echo "(display (map (lambda (d) (util-statistics d)) ldiff)) (newline)" >> diff-tile-15.scm
